﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loginuser.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            // Kallar på klassen 'Tests' och dess metoder.
            Tests.CompareUserInput();
            Tests.CheckUsernameFormat();
            Tests.CheckPasswordFormat();

            // Kallar på klassen 'Integrationtest' och dess metod.
            Integrationtest.CompareUserInput();
        }
    }
}
